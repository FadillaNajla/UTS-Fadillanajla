/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package utsfadilla;

/**
 *
 * @author BELLA
 */
public class UtsFadilla {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Handphone handphone1 = new Handphone ("Samsung", "Merah", 2023);
       
       System.out.println("==Data Handphone==");
       handphone1.tampilkanInformasiHandphone();
    }
    
}
